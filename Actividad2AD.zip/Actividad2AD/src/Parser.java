import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Parser {

	private Document dom = null;
	private ArrayList<libro> libros = null;

	public Parser() {
		libros = new ArrayList<libro>();
	}

	public void parseFicheroXml(String fichero) {
		// creamos una factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {
			// creamos un documentbuilder
			DocumentBuilder db = dbf.newDocumentBuilder();

			// parseamos el XML y obtenemos una representaci�n DOM
			dom = db.parse(fichero);
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (SAXException se) {
			se.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

	}

	public void parseDocument() {
		
		Element docEle = dom.getDocumentElement();

		NodeList nl = docEle.getElementsByTagName("libro");
		if (nl != null && nl.getLength() > 0) {
			for (int i = 0; i < nl.getLength(); i++) {

				Element el = (Element) nl.item(i);			
							
				libro l = getLibro(el);

				libros.add(l);
			}
		}

	}

	private libro getLibro(Element elem) {
		String titulo = getTextValue(elem,"titulo");
		String autor = getNom(elem,"autor");
		String anyo = getAttribute(elem,"anyo");
		String editor = getTextValue(elem,"editor");
		int paginas = getIntValue(elem,"paginas");
		libro l = new libro(titulo,anyo,editor,paginas,autor);

		return l;	
	}
	
	private String getTextValue(Element ele, String tagName) {
		String textVal = null;
		
		NodeList nl = ele.getElementsByTagName(tagName);
		for (int i = 0; i < nl.getLength(); i++) {
			Element el = (Element)nl.item(i);
			textVal = el.getFirstChild().getNodeValue();
			
		}		
		return textVal;
	}
	
	private String getNom(Element ele, String tagName) {
		String textVal = "";
		String textVal1 = null;
		NodeList nl3 = ele.getElementsByTagName(tagName);
		Element el3 = (Element)nl3.item(0);
		
		NodeList nl4 = el3.getElementsByTagName("nombre");
		for (int k = 0; k < nl4.getLength(); k++) {
			Element el4 = (Element)nl4.item(k);
			textVal1= el4.getFirstChild().getNodeValue();
			
			textVal=textVal+" "+textVal1;
		}
		return textVal;
	}			
	
	
	private int getIntValue(Element ele, String tagName) {				
		return Integer.parseInt(getTextValue(ele,tagName));
	}
	
	private String getAttribute(Element ele, String tagName) {
		NodeList nl2 = ele.getElementsByTagName("titulo");
		Element el2 = (Element)nl2.item(0);
		String u= el2.getAttribute(tagName);
		return u;
	}
	
	public void print(){

		Iterator it = libros.iterator();
		while(it.hasNext()) {
			libro l=(libro) it.next();
			l.print();
		}
	}

}
