import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class libro implements Serializable {
	
	
	private String titulo=null;
	private String anyo=null;
	private String editor=null;
	private int pag=0;
	private String autor = null;
	
	public libro() {
		
	}
	
	public libro(String t,String a,String e,int p,String autor2) {
		
		titulo=t;
		autor=autor2;
		editor=e;
		pag=p;
		anyo=a;
		
	}

	public String getAnyo() {
		return anyo;
	}

	public void setAnyo(String anyo) {
		this.anyo = anyo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}	

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getEditor() {
		return editor;
	}

	public void setEditor(String editor) {
		this.editor = editor;
	}

	public int getPag() {
		return pag;
	}

	public void setPag(int pag) {
		this.pag = pag;
	}
	
	public String getAutor() {
		return autor;
	}

	public void print() {
		System.out.println("Titulo: " + titulo + ", autor: " + autor+", a�o: "+anyo+", editor: "+editor+" y n� de paginas: "+pag);
	}


}
